import type { PreguntaSAT } from '$lib/types/question';

// Helper para delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Error personalizado
class QuotaExceededError extends Error {
  retryAfterSeconds: number;
  constructor(message: string, retryAfterSeconds: number) {
    super(message);
    this.name = 'QuotaExceededError';
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

// Generar pregunta individual
export async function generarUnaPregunta(materia: string, dificultad: string): Promise<PreguntaSAT | null> {
  const materiaNormalizada = materia.toLowerCase().trim();
  const dificultadPrompt = {
    easy: 'easy',
    medium: 'medium',
    hard: 'challenging'
  }[dificultad.toLowerCase().trim()] || 'medium';

  const prompt =
    materiaNormalizada === 'reading'
      ? `
You are an SAT reading question generator. Generate ONE question in JSON format:

[
  {
    "pasaje": "A short reading passage (50-150 words).",
    "pregunta": "The multiple-choice question.",
    "opciones": ["Option A", "Option B", "Option C", "Option D"],
    "respuesta": "Correct Answer (must match one option)",
    "explicacion": "Brief explanation for the correct answer."
  }
]

Rules:
- Output only valid JSON (no markdown, no extra text).
- Use double quotes, escape internal quotes.
- The answer MUST exactly match one of the options.
- Explanation must be clear and correct.
- Adjust difficulty to: ${dificultadPrompt}
`
      : `
You are an SAT ${materia} question generator. Generate ONE multiple-choice question in JSON format:

[
  {
    "pregunta": "Question text.",
    "opciones": ["Option A", "Option B", "Option C", "Option D"],
    "respuesta": "Correct Answer",
    "explicacion": "Step-by-step explanation."
  }
]

Rules:
- Return only valid JSON (no markdown, no extra text).
- Use double quotes and escape properly.
- The answer MUST match one of the options.
- Explanation must be complete and correct.
- Difficulty: ${dificultadPrompt}
`;

  try {
    const response = await fetch('/api/generar-pregunta', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));

      if (response.status === 429 && errorData.details) {
        const match = errorData.details.match(/"retryDelay":"(\d+)s"/);
        const retryAfter = match ? parseInt(match[1], 10) : 30;
        throw new QuotaExceededError(`Cuota excedida. Reintenta en ${retryAfter}s.`, retryAfter);
      }

      throw new Error(`Error ${response.status}: ${errorData.error || 'Error desconocido'}`);
    }

    let resultado;
    try {
      resultado = await response.json();
    } catch (parseError) {
      console.error('❌ Error al parsear JSON:', parseError);
      return null;
    }

    if (import.meta.env.DEV) {
      console.log('📥 Respuesta del endpoint:', resultado);
    }

    const p = Array.isArray(resultado) ? resultado[0] : resultado;

    if (
      !p ||
      typeof p.pregunta !== 'string' ||
      !Array.isArray(p.opciones) ||
      p.opciones.length !== 4 ||
      typeof p.respuesta !== 'string'
    ) {
      console.warn('❌ Pregunta malformada o incompleta:', p);
      return null;
    }

    const opcionesLimpias = p.opciones.map((opt: any) => String(opt).trim()).filter(Boolean);
    const respuesta = String(p.respuesta).trim();

    if (!opcionesLimpias.includes(respuesta)) {
      console.warn('❌ La respuesta no coincide con ninguna opción.');
      return null;
    }

    const preguntaFormateada: PreguntaSAT = {
      enunciado: p.pregunta.trim(),
      opciones: opcionesLimpias,
      respuestaCorrecta: respuesta,
      explicacion: typeof p.explicacion === 'string' && p.explicacion.trim().length > 5
        ? p.explicacion.trim()
        : '⚠️ Explicación no disponible.',
    };

    if (typeof p.pasaje === 'string' && p.pasaje.trim().length > 0) {
      preguntaFormateada.pasaje = p.pasaje.trim();
    }

    return preguntaFormateada;
  } catch (err: any) {
    if (err instanceof QuotaExceededError) {
      throw err;
    }

    console.error('❌ Error generando pregunta:', err);
    return null;
  }
}

// Función con reintentos y backoff
export async function generarPreguntaValida(materia: string, dificultad: string): Promise<PreguntaSAT> {
  const maxIntentos = 5;
  let intentos = 0;
  const baseDelay = 1000;

  while (intentos < maxIntentos) {
    try {
      const pregunta = await generarUnaPregunta(materia, dificultad);

      if (
        pregunta &&
        typeof pregunta.enunciado === 'string' &&
        Array.isArray(pregunta.opciones) &&
        pregunta.opciones.length === 4 &&
        typeof pregunta.respuestaCorrecta === 'string' &&
        pregunta.opciones.includes(pregunta.respuestaCorrecta)
      ) {
        return pregunta;
      } else {
        console.warn('❌ Pregunta inválida. Reintentando...');
      }
    } catch (err: any) {
      if (err instanceof QuotaExceededError) {
        console.warn(`⏳ Esperando ${err.retryAfterSeconds}s por cuota...`);
        await delay(err.retryAfterSeconds * 1000 + 1000);
        continue;
      }
      console.error('❌ Error inesperado:', err);
    }

    intentos++;
    if (intentos < maxIntentos) {
      const waitTime = baseDelay * Math.pow(2, intentos - 1);
      console.warn(`🕒 Reintento ${intentos} en ${waitTime / 1000}s...`);
      await delay(waitTime);
    }
  }

  throw new Error(`❌ Falló tras ${maxIntentos} intentos: no se pudo generar una pregunta válida.`);
}
